package pt.ulusofona.lp2.theWalkingDEISIGame;

public class Main {
    public static void main(String[] args) {
        
    }
}
