package pt.ulusofona.lp2.theWalkingDEISIGame;

public class Equipapamento {
    int id;
    int id_tipo;
    int x;
    int y;

    Equipapamento(int id, int id_tipo, int x, int y){
        this.id=id;
        this.id_tipo=id_tipo;
        this.x=x;
        this.y=y;
    }
    Equipapamento(){}
}
