package pt.ulusofona.lp2.theWalkingDEISIGame;

import org.junit.Test;


public class TesteEquipamento {
    @Test
    public void TestEquipamento_Fora(){
        Equipapamento escudo= new Equipapamento(1,2,3,4);



    }
}
